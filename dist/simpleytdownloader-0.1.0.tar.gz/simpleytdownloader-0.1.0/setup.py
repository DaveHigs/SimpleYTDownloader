# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['simpleytdownloader']

package_data = \
{'': ['*']}

install_requires = \
['customtkinter>=5.2.1,<6.0.0',
 'packaging>=23.2,<24.0',
 'pygobject>=3.46.0,<4.0.0',
 'pyqt5-qt5[qt]==5.15.2',
 'pytube>=15.0.0,<16.0.0',
 'tk>=0.1.0,<0.2.0']

setup_kwargs = {
    'name': 'simpleytdownloader',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Simple YouTube Downloader\n\nThis tool provides a user-friendly a graphical user interface (GUI) that allows you to download YouTube videos in either MP4 or MP3 format.\n\n![GUI Screenshot](image.png)\n\n## Features\n\n- Easy-to-use graphical interface.\n- Download YouTube videos in MP4 or MP3 format.\n- Choose download location.\n\n## Usage\n\n1. Launch the application.\n2. Copy the URL of the YouTube video you want to download.\n3. Paste the URL into the application.\n4. Select the desired format (MP4 or MP3).\n5. Click the "Download" button.\n6. Choose download location and file name.\n\n## Build from Source\n\nIf you want to build the application from the source code, follow these steps:\n\n1. Clone this repository:\n\n```sh\ngit clone https://github.com/DaveHigs/SimpleYTDownloader\n```\n\n2. Navigate to the project directory:\n\n```sh\ncd SimpleYTDownloader\n```\n\n3. Install the dependencies:\n\n```sh\npoetry install\n```\n\n4. Run the application:\n\n```sh\npoetry run python main.py\n```\n\n## License\n\nThis project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.\n',
    'author': 'David',
    'author_email': 'david.higuera1@hotmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
